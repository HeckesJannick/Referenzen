﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zeiterfassung_V1_Heckes
{
    public partial class Form1 : Form
    {
        protected Panel window;
        
        public Form1()
        {
            window = new Panel();
            window.BackColor = Color.White;
            window.Width = 1920;
            window.Height = 1080;
            Controls.Add(window);
            InitializeComponent();
            UI.CreateUI(window);
        }
    }
}
