﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Zeiterfassung_V1_Heckes
{
    class Handler
    {
        public void HandleSaving(string name, string firstname, string time)
        {
            string filePath = @"C:\Users\jHeck\Desktop\Zentrale\Arbeitsplatz\Coding\VS Studio Projekte\Zeiterfassung_V1_Heckes\bin\benutzerdaten.txt";

            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine("Name: " + name);
                writer.WriteLine("Vorname: " + firstname);
                writer.WriteLine("Uhrzeit: " + time);
            }
            Debug.WriteLine("Daten gespeichert.");

            MessageBox.Show("Die Daten wurden in die Datei gespeichert: " + filePath);
        }
        public void HandleDelete()
        {
            string filePath = @"C:\Users\jHeck\Desktop\Zentrale\Arbeitsplatz\Coding\VS Studio Projekte\Zeiterfassung_V1_Heckes\bin\benutzerdaten.txt";

            try
            {
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                    MessageBox.Show("Die Datei wurde erfolgreich gelöscht.");
                }
                else
                {
                    MessageBox.Show("Die Datei existiert nicht.");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Fehler beim Löschen der Datei: " + ex.Message);
                MessageBox.Show("Fehler beim Löschen der Datei: " + ex.Message);
            }
        }
    }
}
