﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
using System.Xml.Linq;
using System.Reflection;

namespace Zeiterfassung_V1_Heckes
{
    public class UI : Form1
    {

        public static void CreateUI(Panel window)
        {
            Label name = new Label();
            name.Text = "Name";
            name.Height = 20;
            name.Width = 40;
            name.Location = new Point(10, 10);
            name.Visible = true;

            Label firstname = new Label();
            firstname.Text = "Vorname";
            firstname.Height = 20;
            firstname.Width = 60;
            firstname.Location = new Point(name.Right + 80, 10);
            firstname.Visible = true;

            Label time = new Label();
            time.Text = "Uhrzeit";
            time.Height = 20;
            time.Width = 40;
            time.Location = new Point(firstname.Right + 80, 10); 
            time.Visible = true;

            TextBox tbName = new TextBox();
            tbName.Height = 40;
            tbName.Width = 60;
            tbName.Location = new Point(10, 30);
            tbName.Visible = true;

            TextBox tbfirstname = new TextBox();
            tbfirstname.Height = 20;
            tbfirstname.Width = 60;
            tbfirstname.Location = new Point(130, 30);
            tbfirstname.Visible = true;

            MaskedTextBox tbTime = new MaskedTextBox();
            tbTime.Height = 20;
            tbTime.Width = 60;
            tbTime.Location = new Point(270, 30);
            tbTime.Visible = true;
            tbTime.Mask = "00:00";

            Button bSaving = new Button();
            bSaving.Height =25;
            bSaving.Width = 200;
            bSaving.Location = new Point(10, 90);
            bSaving.Text = "Eingabe speichern";
            bSaving.Click += (sender, e) => {
            saving(sender, e, tbName.Text, tbfirstname.Text, tbTime.Text);
            };


            Button delete = new Button();
            delete.Height = 25;
            delete.Width = 200;
            delete.Location = new Point(220, 90);
            delete.Text = "Eingabe löschen";
            
            window.Controls.Add(name);
            window.Controls.Add(firstname);  
            window.Controls.Add(time);
            window.Controls.Add(tbName);
            window.Controls.Add(tbfirstname);
            window.Controls.Add(tbTime);
            window.Controls.Add(bSaving);
            window.Controls.Add(delete);
        }

        public static void saving(object sender, System.EventArgs e, string name, string firstname, string time)
        {
            Handler call = new Handler();

            call.HandleSaving(name, firstname, time);
        }

        private static void delete(object sender, System.EventArgs e)
        {
            Handler call = new Handler();
            call.HandleDelete();
        }
    }
}
